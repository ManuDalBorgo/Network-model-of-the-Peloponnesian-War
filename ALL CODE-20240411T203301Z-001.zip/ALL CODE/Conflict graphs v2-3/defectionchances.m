function [node_defection_matrix] = defectionchances(mapstate, parameters)
%DEFECTIONCHANCES Summary of this function goes here
%   Detailed explanation goes here
outputArg1 = inputArg1;
outputArg2 = inputArg2;
end

